import os
import pickle
import hashlib
def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    print(safecode)
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
