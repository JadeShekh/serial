import os
import pickle
import hashlib
hash="195d1271cb30e1d82ee4f423b83512188810625137f081fe9e3394328ec79df1" # for jitender,jitender username and password
def reverse_fun():
      with open("users.json","rb") as f:
          data = f.read()
      h = hashlib.new('sha512_256')
      h.update((data))
      h.hexdigest()
      print(h.hexdigest())
      if (hash==h.hexdigest()):
      	   print("match")
      	   d = pickle.loads(data)
      	   return d
      else:
           return("integrity mismatch")

if __name__ == '__main__':
      print(reverse_fun())
